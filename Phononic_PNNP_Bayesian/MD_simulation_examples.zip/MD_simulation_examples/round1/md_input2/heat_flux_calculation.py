import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

all_results = []

for folder_index in range(1, 401):
    folder = f"set{folder_index}"
    file_path1 = f'./{folder}/log.net2422R0_{folder}'
    file_path2 = f'./{folder}/net2422R0_{folder}_flux.txt'

    data = pd.read_csv(file_path2, header=None, sep=r"\s+", comment='#')

    data = np.array(data)

    t=data[:,0]/4000000
    T=data[:,1]
    q1=data[:,2]
    q2=data[:,3]
    q3=data[:,4]
    q4=data[:,5]
    q5=data[:,6]
    q6=data[:,7]
    q7=data[:,8]
    q8=data[:,9]
    q9=data[:,10]
    q10=data[:,11]


    # Initialize an empty list to store integers
    Tset = []

    # Open the file and read line by line
    with open(file_path1, 'r') as file:
        for line in file:
            if "variable Tset equal" in line:
                Tset.append(int(float(line.split()[-1])))
            elif any(f"variable T{i} equal" in line for i in range(1, 11)):
                Tset.append(int(float(line.split()[-1])))

    # Display the collected first integers
    #print(Tset)

    fig = plt.figure(figsize=(8, 20))

    plt.subplot(5, 1, 1)
    plt.plot(t, T)
    plt.xlabel('Simulation time (ns)')
    plt.ylabel('Temperature (K)')
    #plt.legend(['2nm','4nm','9nm','12nm'])

    plt.subplot(5, 1, 2)
    plt.plot(t, q1, label=f'NP1, T={Tset[1]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(t, q2, label=f'NP2, T={Tset[2]}K')  # Second line plot with label including temperature from Tset[1]
    plt.xlabel('Simulation time (ns)')
    plt.ylabel('Heat (kcal/mol)')
    plt.legend()

    plt.subplot(5, 1, 3)
    plt.plot(t, q3, label=f'NP3, T={Tset[3]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(t, q4, label=f'NP4, T={Tset[4]}K')  # Second line plot with label including temperature from Tset[1]
    plt.plot(t, q5, label=f'NP5, T={Tset[5]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(t, q6, label=f'NP6, T={Tset[6]}K')  # Second line plot with label including temperature from Tset[1]
    plt.xlabel('Simulation time (ns)')
    plt.ylabel('Heat (kcal/mol)')
    plt.legend()

    plt.subplot(5, 1, 4)
    plt.plot(t, q7, label=f'NP7, T={Tset[7]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(t, q8, label=f'NP8, T={Tset[8]}K')  # Second line plot with label including temperature from Tset[1]
    plt.xlabel('Simulation time (ns)')
    plt.ylabel('Heat (kcal/mol)')
    plt.legend()

    plt.subplot(5, 1, 5)
    plt.plot(t, q9, label=f'NP9, T={Tset[9]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(t, q10, label=f'NP10, T={Tset[10]}K')  # Second line plot with label including temperature from Tset[1]
    plt.xlabel('Simulation time (ns)')
    plt.ylabel('Heat (kcal/mol)')
    plt.legend()

    plt.savefig(f'plot_heat_{folder}.pdf')

    def backward_slope(t, q1, dt=1, t_end=2.0):
        """
        Computes the backward slope (finite difference) of q1 with respect to t,
        using a fixed interval dt. The slope is assigned to the right endpoint.

        Parameters:
            t (np.ndarray): 1D array of time values.
            q1 (np.ndarray): 1D array of values at corresponding times.
            dt (float): Interval to use for backward differencing.

        Returns:
            t_slope (np.ndarray): Times at which slopes are computed (right endpoint).
            dq1_dt (np.ndarray): Backward slope values at those times.
        """
        t = np.asarray(t)
        q1 = np.asarray(q1)

        t_slope = []
        dq1_dt = []

        #for i in range(len(t)):
        for i in range(int(t_end*400)):
            t1 = t[i]
            t0 = t1 - dt
            if t0 < t[0]:
                continue  # Skip if window goes out of bounds

            idx0 = np.searchsorted(t, t0)
            idx1 = i

            mask = (t >= t0) & (t <= t1)
            t_window = t[mask]
            q1_window = q1[mask]
            if len(t_window) >= 2:
                coeffs = np.polyfit(t_window, q1_window, 1)  # degree 1 for linear fit
                slope = coeffs[0]  # slope is the first coefficient
                t_slope.append(t1)  # or (t0 + t1) / 2 if you prefer midpoint
                dq1_dt.append(slope)

            # Ensure t values match exactly for reliable slope
    #        if t[idx0] == t0 and t[idx1] == t1:
    #            dq = q1[idx1] - q1[idx0]
    #            slope = dq / dt
    #            t_slope.append(t1)
    #            dq1_dt.append(slope)

        return np.array(t_slope), np.array(dq1_dt)

    ts, dq1 = backward_slope(t,q1)
    ts, dq2 = backward_slope(t,q2)
    ts, dq3 = backward_slope(t,q3)
    ts, dq4 = backward_slope(t,q4)
    ts, dq5 = backward_slope(t,q5)
    ts, dq6 = backward_slope(t,q6)
    ts, dq7 = backward_slope(t,q7)
    ts, dq8 = backward_slope(t,q8)
    ts, dq9 = backward_slope(t,q9)
    ts, dq10 = backward_slope(t,q10)

    fig = plt.figure(figsize=(10, 6))

    plt.subplot(2, 2, 1)
    plt.plot(ts, dq1, label=f'NP1, T={Tset[1]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(ts, dq2, label=f'NP2, T={Tset[2]}K')  # Second line plot with label including temperature from Tset[1]
    plt.xlabel('Simulation time (ns)')
    plt.ylabel('Heat (kcal/mol/ns)')
    plt.legend()

    plt.subplot(2, 2, 2)
    plt.plot(ts, dq3, label=f'NP3, T={Tset[3]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(ts, dq4, label=f'NP4, T={Tset[4]}K')  # Second line plot with label including temperature from Tset[1]
    plt.plot(ts, dq5, label=f'NP5, T={Tset[5]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(ts, dq6, label=f'NP6, T={Tset[6]}K')  # Second line plot with label including temperature from Tset[1]
    plt.xlabel('Simulation time (ns)')
    plt.ylabel('Heat (kcal/mol/ns)')
    plt.legend()

    plt.subplot(2, 2, 3)
    plt.plot(ts, dq7, label=f'NP7, T={Tset[7]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(ts, dq8, label=f'NP8, T={Tset[8]}K')  # Second line plot with label including temperature from Tset[1]
    plt.xlabel('Simulation time (ns)')
    plt.ylabel('Heat (kcal/mol/ns)')
    plt.legend()

    plt.subplot(2, 2, 4)
    plt.plot(ts, dq9, label=f'NP9, T={Tset[9]}K')  # First line plot with label including temperature from Tset[0]
    plt.plot(ts, dq10, label=f'NP10, T={Tset[10]}K')  # Second line plot with label including temperature from Tset[1]
    plt.xlabel('Simulation time (ns)')
    plt.ylabel('Heat (kcal/mol/ns)')
    plt.legend()

    plt.savefig(f'plot_heatflux_{folder}.pdf')


    result = np.zeros((10, 2)) 
    dq_list = [dq1, dq2, dq3, dq4, dq5, dq6, dq7, dq8, dq9, dq10]

    result = []

    for dq in dq_list:  # or however you're looping
        result.extend([np.mean(dq[-400:])])

    #result = np.array(result)  # shape = (num_rows, 2)
    #for i, dq in enumerate(dq_list, start=0):
    #    result[i, :] = np.array([dq[-400:]]).mean(), np.array([dq[-400:]]).std()
    #print(result)
    all_results.append(result)

#p.savetxt(f"heatflux_{folder}.csv", [result], delimiter=",", fmt="%.6f")
all_results = np.array(all_results)  # shape (100, 2*len(dq_list))
np.savetxt("heatflux_all.csv", all_results, delimiter=",", fmt="%.6f")

